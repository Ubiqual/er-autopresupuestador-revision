'use client';

import ErrorIcon from '@/assets/icons/error-icon.svg';
import ArrowRight from '@/assets/icons/right-arrow.svg';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { ToastType } from '@/contexts/ToastModalContext';
import { cn } from '@/lib/utils';
import { t } from '@/utils/i18n';
import * as React from 'react';
import { Button } from '../ui';

interface ToastModalProps {
  open: boolean;
  message: string;
  toastType: ToastType;
  title: string;
  onClose: () => void;
}

export default function ToastModal({ open, message, toastType, onClose, title }: ToastModalProps) {
  const GTMId =
    message === t('admin.success.bookingSaved')
      ? 'presupuestador_autocares_guardar_presupuesto'
      : message === t('admin.success.bookingRequested')
        ? 'presupuestador_autocares_solicitar_presupuesto'
        : undefined;
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent
        className={cn(
          'fixed top-1/2 left-1/2 bg-white transform -translate-x-1/2 -translate-y-1/2 z-[9999] flex flex-col rounded-3xl',
          'w-[100%] xl:w-[45%] max-w-[100%] xl:max-w-[35vw] min-h-[300px]'
        )}
      >
        <DialogTitle className="flex-1 p-4 overflow-y-auto flex flex-col items-center justify-center">
          {title}
        </DialogTitle>

        <div className="flex-1 p-4 overflow-y-auto flex flex-col items-center justify-center">
          {toastType === ToastType.error && <ErrorIcon width={35} height={35} />}
          <p className="mt-4 text-black/80" id={GTMId}>
            {message}
          </p>
        </div>

        <footer className="p-4 flex w-full items-center justify-center">
          <Button
            variant="default"
            rounded="full"
            color="primary"
            suffixIcon={<ArrowRight className="ml-20" height={28} width={28} />}
            size="lg"
            onClick={onClose}
            className="w-full md:w-auto"
          >
            {t('admin.buttons.review')}
          </Button>
        </footer>
      </DialogContent>
    </Dialog>
  );
}
