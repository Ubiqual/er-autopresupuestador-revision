'use client';

import type { Locale } from 'date-fns';
import { format } from 'date-fns';
import * as React from 'react';

import CalendarIcon from '@/assets/icons/calendar-outline.svg';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { cn } from '@/lib/utils';
import { getI18nLocale, t } from '@/utils/i18n';
import { enUS, es } from 'date-fns/locale';

export function DatePicker({
  date,
  disabled = false,
  onDateChange,
  placeholder,
  allowPastDates
}: {
  date: Date | undefined;
  disabled?: boolean;
  onDateChange: (date: Date) => void;
  placeholder?: string;
  allowPastDates?: boolean;
}) {
  const today = new Date();
  const [popoverOpen, setPopoverOpen] = React.useState(false);

  const placeholderText = placeholder ?? t('bookingPage.placeholders.pickupDate');
  const handleDateSelect = (selectedDate: Date | undefined) => {
    onDateChange(selectedDate as Date);
    setPopoverOpen(false);
  };

  const currentLocale = getI18nLocale();
  const localeMap: { [key: string]: Locale } = {
    en: enUS,
    es: es
  };
  const selectedLocale = localeMap[currentLocale] || enUS;

  return (
    <Popover open={popoverOpen} onOpenChange={setPopoverOpen} modal={false}>
      <PopoverTrigger asChild>
        <Button
          variant={'outline'}
          onClick={() => setPopoverOpen(true)}
          className={cn(
            `min-w-full text-md justify-start text-left font-normal', !date && 'text-muted-foreground ${date ? 'text-[#313131]' : 'text-[#bfbfbf] italic hover:text-[#bfbfbf]'} border-[#000000] rounded'`
          )}
          rounded={'full'}
          disabled={disabled}
        >
          <CalendarIcon className="mr-2" width={24} height={24} />
          {date ? format(date, 'PPP', { locale: selectedLocale }) : <span>{placeholderText}</span>}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0">
        <Calendar
          mode="single"
          selected={date}
          onSelect={handleDateSelect}
          initialFocus
          fromDate={allowPastDates ? undefined : today}
          defaultMonth={date || today}
        />
      </PopoverContent>
    </Popover>
  );
}
