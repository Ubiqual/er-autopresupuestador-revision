import { cn } from '@/lib/utils';
import { getI18nLocale } from '@/utils/i18n';
import type { Locale } from 'date-fns';
import { addMinutes, format, setMinutes, setSeconds } from 'date-fns';
import { enUS, es } from 'date-fns/locale';
import * as React from 'react';
import { LoadingContent } from './loading';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './select';

export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'prefix'> {
  suffix?: React.ReactNode;
  prefix?: React.ReactNode; // Ensure prefix prop is added here
  isTimeInput?: boolean;
  minTime?: string; // in 'yyyy-MM-dd HH:mm' format
  maxTime?: string; // in 'yyyy-MM-dd HH:mm' format
  placeholderName?: string;
  loading?: boolean; // Add a loading prop
  hideDate?: boolean; // Add hideDate prop
}

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  (
    {
      className,
      type,
      suffix,
      prefix, // Ensure prefix prop is added here
      isTimeInput,
      minTime,
      disabled,
      maxTime,
      placeholderName,
      loading = false,
      hideDate = false,
      ...props
    },
    ref
  ) => {
    const currentLocale = getI18nLocale();
    const localeMap: { [key: string]: Locale } = {
      en: enUS,
      es: es
    };
    const selectedLocale = localeMap[currentLocale] || enUS;

    const [selectedValue, setSelectedValue] = React.useState(props.value as string);

    const timeOptions = React.useMemo(() => {
      const times: { label: string; value: string }[] = [];

      if (!minTime || !maxTime) {
        return times;
      }

      // Parse minTime and maxTime to Date objects
      const minTimeParsed = new Date(minTime);
      const maxTimeParsed = new Date(maxTime);

      // Round minTime to the next available 30-minute interval
      let currentTime = setMinutes(minTimeParsed, Math.ceil(minTimeParsed.getMinutes() / 30) * 30);
      currentTime = setSeconds(currentTime, 0); // Ensure seconds are set to 0

      // Generate time slots from the rounded minTime to maxTime
      while (currentTime <= maxTimeParsed) {
        // Format time and date for the current slot
        const formattedTime = format(currentTime, 'HH:mm');
        const formattedDate = format(currentTime, 'MMM dd', { locale: selectedLocale });

        // Always include the date
        const timeLabel = hideDate ? formattedTime : `${formattedTime} (${formattedDate})`;

        times.push({
          label: timeLabel,
          value: format(currentTime, 'yyyy-MM-dd HH:mm')
        });

        // Increment by 30 minutes
        currentTime = addMinutes(currentTime, 30);
      }

      return times;
    }, [minTime, maxTime, selectedLocale]);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (!isTimeInput) {
        setSelectedValue(e.target.value);
      }
    };

    const handleTimeChange = (value: string) => {
      setSelectedValue(value);
      if (props.onChange) {
        props.onChange({
          target: { value: value }
        } as unknown as React.ChangeEvent<HTMLInputElement>);
      }
    };

    React.useEffect(() => {
      setSelectedValue(props.value as string);
    }, [props.value]);

    return (
      <div className="relative w-full">
        {isTimeInput ? (
          <Select disabled={disabled} value={selectedValue} onValueChange={handleTimeChange}>
            <SelectTrigger
              className={cn(
                `w-full h-[2.6875rem] text-md ${selectedValue ? 'text-[#313131]' : 'text-[#bfbfbf] italic'} border-[#000000] rounded-full`,
                className
              )}
            >
              <SelectValue placeholder={placeholderName ?? 'Select an option'} />
            </SelectTrigger>
            <SelectContent className="absolute left-0 z-50">
              {loading ? (
                <div className="flex justify-center py-2">
                  <LoadingContent className="h-4 w-4" />
                </div>
              ) : (
                timeOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
        ) : (
          <input
            type={type}
            className={cn(
              `flex h-[2.6875rem] w-full rounded-md border px-3 py-2 text-md focus-visible:outline-none disabled:cursor-not-allowed disabled:opacity-50 disabled:bg-white ${selectedValue ? 'text-[#313131]' : 'text-[#bfbfbf] italic'} border-[#000000] rounded-full`,
              suffix ? 'pr-10' : '',
              prefix ? 'pl-10' : '', // Adjust padding for prefix
              className
            )}
            ref={ref}
            value={selectedValue}
            onChange={handleInputChange}
            readOnly={isTimeInput}
            disabled={disabled}
            {...props}
          />
        )}
        {prefix && <span className="absolute inset-y-0 left-0 flex items-center pl-3">{prefix}</span>}
        {suffix && <span className="absolute inset-y-0 right-0 flex items-center pr-3">{suffix}</span>}
      </div>
    );
  }
);

Input.displayName = 'Input';

export { Input };
