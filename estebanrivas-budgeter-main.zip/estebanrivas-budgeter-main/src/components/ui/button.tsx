'use client';

import { Slot } from '@radix-ui/react-slot';
import { cva, type VariantProps } from 'class-variance-authority';
import * as React from 'react';

import { cn } from '@/lib/utils';
import { LoadingContent } from './loading';

const buttonVariants = cva(
  'inline-flex items-center justify-center whitespace-nowrap text-md font-medium ring-offset-white transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-slate-950 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 dark:ring-offset-slate-950 dark:focus-visible:ring-slate-300',
  {
    variants: {
      variant: {
        default:
          'bg-slate-900 text-slate-50 hover:bg-slate-900/90 dark:bg-slate-50 dark:text-slate-900 dark:hover:bg-slate-50/90',
        destructive:
          'bg-red-500 text-slate-50 hover:bg-red-500/90 dark:bg-red-900 dark:text-slate-50 dark:hover:bg-red-900/90',
        outline:
          'border border-[#3b4da0] text-[#3b4da0] bg-white hover:bg-slate-100 hover:text-[#3b4da0] dark:border-slate-800 dark:bg-slate-950 dark:hover:bg-slate-800 dark:hover:text-slate-50',
        secondary:
          'bg-slate-100 text-slate-900 hover:bg-slate-100/80 dark:bg-slate-800 dark:text-slate-50 dark:hover:bg-slate-800/80',
        ghost: 'hover:opacity-80 dark:hover:bg-slate-800 dark:hover:text-slate-50',
        link: 'text-slate-900 underline-offset-4 hover:underline dark:text-slate-50'
      },
      size: {
        default: 'h-[2.6875rem] px-4 py-2',
        sm: 'h-9 px-3',
        lg: 'h-11 px-8',
        xl: 'h-[3.125rem] w-[212px]',
        icon: 'h-9 w-9 '
      },
      rounded: {
        default: 'rounded-md',
        md: 'rounded-md',
        lg: 'rounded-lg',
        full: 'rounded-full'
      },
      color: {
        default: '',
        primary: 'bg-[#3b4da0] hover:bg-[#3b4da0]/90',
        secondary: 'bg-green-500 hover:bg-green-500/90',
        danger: 'bg-red-500 hover:bg-red-500/90',
        white: 'bg-white hover:bg-white/90'
      }
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
      rounded: 'default',
      color: 'default'
    }
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  loading?: boolean;
  suffixIcon?: React.ReactNode;
  prefixIcon?: React.ReactNode;
  color?: 'default' | 'primary' | 'secondary' | 'danger' | 'white';
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      className,
      variant,
      size,
      rounded,
      asChild = false,
      loading = false,
      disabled = false,
      suffixIcon,
      prefixIcon,
      color = 'default',
      ...props
    },
    ref
  ) => {
    const Comp = asChild ? Slot : 'button';
    const contentClasses = loading
      ? 'flex justify-center items-center p-4'
      : (prefixIcon || suffixIcon) && 'flex justify-between p-4';
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, rounded, color, className }), contentClasses)}
        ref={ref}
        disabled={loading || disabled}
        {...props}
      >
        {prefixIcon && !loading && <span className="mr-2">{prefixIcon}</span>}
        {loading ? <LoadingContent className="h-4 w-4" /> : props.children}
        {suffixIcon && !loading && <span className="ml-2">{suffixIcon}</span>}
      </Comp>
    );
  }
);

Button.displayName = 'Button';

export { Button, buttonVariants };
