import { Button } from '@/components/ui/index';
import type { Service } from '@prisma/client';
import React from 'react';

type ServiceSelectorProps = {
  services: Service[];
  selectedService: Service;
  loading: boolean;
  onSelectService: (service: Service) => void;
};

const ServiceSelectorOldDesign: React.FC<ServiceSelectorProps> = ({
  services,
  selectedService,
  loading,
  onSelectService
}) => {
  return (
    <div className="flex flex-wrap gap-2 mb-4">
      {services.map((service) => (
        <Button
          key={service.name}
          variant={selectedService.name === service.name ? 'default' : 'outline'}
          className="rounded-full h-[28px] md:h-[35px]"
          onClick={() => onSelectService(service)}
          style={loading ? { opacity: 0.5 } : { opacity: 1 }}
          disabled={loading}
        >
          {service.name}
        </Button>
      ))}
    </div>
  );
};

export default ServiceSelectorOldDesign;
