import Bus from '@/assets/icons/bus.svg';
import Forest from '@/assets/icons/forest.svg';
import Plane from '@/assets/icons/plane.svg';
import Rings from '@/assets/icons/rings.svg';
import Train from '@/assets/icons/train.svg';
import Travel from '@/assets/icons/travel.svg';
import { cn, formatName } from '@/lib/utils';
import type { Service } from '@prisma/client';
import React from 'react';

type ServiceSelectorProps = {
  services: Service[];
  selectedService: Service | null;
  loading: boolean;
  onSelectService: (service: Service) => void;
};

const serviceIcons: Record<string, JSX.Element> = {
  traslados: <Bus width={33} height={33} style={{ currentColor: '#fffff xl:#3B4DA0' }} />,
  'transfer aeropuerto': <Plane width={33} height={33} style={{ currentColor: '#fffff xl:#3B4DA0' }} />,
  'transfer tren': <Train width={33} height={33} style={{ currentColor: '#fffff xl:#3B4DA0' }} />,
  excursiones: <Forest width={33} height={33} style={{ currentColor: '#fffff xl:#3B4DA0' }} />,
  viajes: <Travel width={33} height={33} style={{ currentColor: '#fffff xl:#3B4DA0' }} />,
  bodas: <Rings width={33} height={33} style={{ currentColor: '#fffff xl:#3B4DA0' }} />
};

const ServiceSelector: React.FC<ServiceSelectorProps> = ({ services, selectedService, loading, onSelectService }) => {
  return (
    <div className="relative w-full pb-1 overflow-x-auto xl:overflow-visible">
      <div className="mx-auto w-full overflow-x-hidden xl:max-w-none">
        <div className="flex flex-col xl:flex-wrap xl:flex-row xl:items-center xl:justify-between mx-auto xl:gap-4">
          {services
            .map((service) => {
              const { name } = service;
              return {
                hardCodeName: formatName(name),
                ...service
              };
            })
            .map((service, index) => {
              const isSelected = selectedService?.name === service.name;
              return (
                <button
                  key={service.name}
                  onClick={() => onSelectService(service)}
                  disabled={loading}
                  style={loading ? { opacity: 0.5 } : undefined}
                  className={cn(
                    'relative transition-all duration-200 h-10 pb-0 xl:pb-2',
                    'w-full xl:w-auto flex flex-col items-start xl:inline-flex xl:items-center justify-center',
                    'xl:text-[1rem] xl:flex-shrink-0 border-b-2 xl:border-[#4554a1] xl:border-b',
                    index === 0 || index === services.length - 1
                      ? index === 0
                        ? 'xl:pr-4 px-4 xl:px-0'
                        : 'xl:pl-4 px-4 xl:px-0'
                      : 'px-4',
                    !isSelected
                      ? 'text-[#4554a1] font-bold'
                      : 'bg-[#4554a1] text-white font-normal xl:bg-transparent xl:text-[#4554a1]'
                  )}
                >
                  <div className="flex justify-start items-center gap-1">
                    {serviceIcons[String(service.name).toLowerCase()] || null}
                    <div>
                      <span
                        className={cn(
                          isSelected ? 'font-bold' : 'font-normal',
                          'text-xs sm:text-base text-left line-clamp-1'
                        )}
                      >
                        {service.hardCodeName.toLowerCase()}
                      </span>
                    </div>
                  </div>

                  {/* <div className="absolute  bottom-[0px] bg-transparent xl:bottom-[1px] left-0 w-full h-[0px] xl:h-[1px] xl:bg-[#4554a1]" /> */}

                  <div
                    className={`absolute bottom-0 left-0 w-full h-[3px] rounded-lg transition-all duration-200 ${
                      selectedService?.name === service.name ? 'bg-transparent xl:bg-[#4554a1]' : 'xl:bg-transparent'
                    }`}
                  />
                </button>
              );
            })}
        </div>
      </div>
    </div>
  );
};

export default ServiceSelector;
