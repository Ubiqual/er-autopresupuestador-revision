module.exports = {
  parser: '@typescript-eslint/parser',
  plugins: ['@typescript-eslint'],
  extends: ['next/core-web-vitals', 'eslint:recommended', 'plugin:@typescript-eslint/recommended', 'prettier'],
  rules: {
    'no-console': process.env.CHECK_PR ? 'error' : 'off',
    curly: 'warn',
    '@typescript-eslint/no-unused-vars': process.env.CHECK_PR ? 'error' : 'warn',
    'no-dupe-else-if': 'warn',
    'no-import-assign': 'warn',
    'no-setter-return': 'warn',
    'require-await': 'warn',
    quotes: ['warn', 'single'],
    indent: [
      'warn',
      2,
      {
        SwitchCase: 1,
        VariableDeclarator: 1,
        outerIIFEBody: 1,
        MemberExpression: 1,
        FunctionDeclaration: { parameters: 1, body: 1 },
        FunctionExpression: { parameters: 1, body: 1 },
        CallExpression: { arguments: 1 },
        ArrayExpression: 1,
        ObjectExpression: 1,
        ImportDeclaration: 1,
        flatTernaryExpressions: false,
        ignoreComments: false,
        offsetTernaryExpressions: true
      }
    ],
    semi: ['warn', 'always'],
    '@typescript-eslint/consistent-type-imports': 'error',
    '@typescript-eslint/naming-convention': [
      'error',
      {
        selector: 'typeAlias',
        format: ['PascalCase']
      },
      {
        selector: 'interface',
        format: ['PascalCase']
      },
      {
        selector: 'typeParameter',
        format: ['PascalCase']
      }
    ],
    'react-hooks/exhaustive-deps': 'off',
    'max-lines': ['warn', { max: 300 }]
  }
};
